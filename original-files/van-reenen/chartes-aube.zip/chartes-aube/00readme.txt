From: "Piet van Reenen" <p.van.reenen@let.vu.nl>
Subject:  corpus Troyes
To: Achim Stein <achim.stein@ling.uni-stuttgart.de>,
	<kunstman@uottawa.ca>, <peter.blumenthal@uni-koeln.de>
X-Mailer: CommuniGate Pro WebUser Interface v.4.1.8
Date: Tue, 01 Feb 2005 16:44:55 +0100
Message-ID: <web-10351434@let.vu.nl>
In-Reply-To: <41FE0FE1.9030809@ling.uni-stuttgart.de>
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="_===10351434====let.vu.nl===_"
X-Virus-Scanned: by amavisd-new at medousa.rus.uni-stuttgart.de

This is a multi-part MIME message

--_===10351434====let.vu.nl===_
Content-Type: text/plain; charset="ISO-8859-1"
Content-Transfer-Encoding: quoted-printable



Chers collegues,

Voici la version electronique de 75 chartes de l Aube,
derniere version, en principe definitive.

Je vous envoie par courrier traditionnel la version
provisoire imprimee de l edition.

Si vous avez des commentaires sur cette version pour encore
l ameliorer avant la publication definitive, je serais tres
content.

Tres cordialement,

Pieter van Reenen


 